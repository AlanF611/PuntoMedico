import { useState, useEffect } from 'react';
import { calculateShipping } from '../services/dhl';

interface UseShippingProps {
  originPostalCode: string;
  destinationPostalCode: string;
  weight: number;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
}

export const useShipping = ({
  originPostalCode,
  destinationPostalCode,
  weight,
  dimensions
}: UseShippingProps) => {
  const [rates, setRates] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRates = async () => {
      if (!destinationPostalCode || destinationPostalCode.length !== 5) {
        setError('Ingresa un código postal válido de 5 dígitos');
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const shippingRates = await calculateShipping(
          {
            postalCode: originPostalCode,
            cityName: 'Guadalajara',
            countryCode: 'MX'
          },
          {
            postalCode: destinationPostalCode,
            cityName: '',
            countryCode: 'MX'
          },
          [{
            weight: Math.max(0.1, weight), // Mínimo 100g
            length: Math.max(1, dimensions.length),
            width: Math.max(1, dimensions.width),
            height: Math.max(1, dimensions.height)
          }]
        );

        setRates(shippingRates);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error al calcular costos de envío');
      } finally {
        setLoading(false);
      }
    };

    // Debounce para evitar llamadas excesivas
    const timeoutId = setTimeout(fetchRates, 500);
    return () => clearTimeout(timeoutId);
  }, [originPostalCode, destinationPostalCode, weight, dimensions]);

  return { rates, loading, error };
};