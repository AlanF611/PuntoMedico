import React, { useState } from 'react';
import { useShipping } from '../hooks/useShipping';
import { Truck, Loader, AlertCircle } from 'lucide-react';

interface ShippingCalculatorProps {
  weight: number;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  onRateSelect: (rate: any) => void;
}

const ShippingCalculator: React.FC<ShippingCalculatorProps> = ({
  weight,
  dimensions,
  onRateSelect
}) => {
  const [postalCode, setPostalCode] = useState('');
  const { rates, loading, error } = useShipping({
    originPostalCode: '44100', // Código postal de Guadalajara
    destinationPostalCode: postalCode,
    weight,
    dimensions
  });

  const handlePostalCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 5);
    setPostalCode(value);
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Código Postal de Entrega
        </label>
        <div className="mt-1 relative">
          <input
            type="text"
            value={postalCode}
            onChange={handlePostalCodeChange}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            placeholder="Ej: 44100"
          />
          {postalCode && postalCode.length !== 5 && (
            <div className="absolute right-0 top-0 h-full flex items-center pr-3">
              <AlertCircle className="h-5 w-5 text-yellow-500" />
            </div>
          )}
        </div>
        <p className="mt-1 text-sm text-gray-500">
          Dimensiones del paquete: {dimensions.length}x{dimensions.width}x{dimensions.height}cm
          <br />
          Peso: {weight}kg
        </p>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-4">
          <Loader className="h-6 w-6 animate-spin text-blue-600" />
          <span className="ml-2 text-gray-600">Calculando costos de envío...</span>
        </div>
      )}

      {error && (
        <div className="text-red-600 text-sm flex items-center gap-2">
          <AlertCircle className="h-5 w-5" />
          {error}
        </div>
      )}

      {!loading && !error && rates.length > 0 && (
        <div className="space-y-3">
          {rates.map((rate) => (
            <label
              key={rate.service}
              className="block p-4 border rounded-lg hover:border-blue-500 cursor-pointer transition-all duration-200"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Truck className="h-6 w-6 text-blue-600" />
                  <div>
                    <p className="font-medium">DHL {rate.service}</p>
                    <p className="text-sm text-gray-500">{rate.deliveryTime}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">${rate.totalAmount.toLocaleString()}</p>
                  <button
                    onClick={() => onRateSelect(rate)}
                    className="text-sm text-blue-600 hover:text-blue-700 transition-colors duration-200"
                  >
                    Seleccionar
                  </button>
                </div>
              </div>
            </label>
          ))}
        </div>
      )}
    </div>
  );
};