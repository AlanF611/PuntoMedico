import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Menu, X, Stethoscope } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [lightText, setLightText] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY > 10;
      setIsScrolled(scrolled);
      
      // Solo verificar el color del texto si no hemos hecho scroll
      if (!scrolled) {
        checkTextColor();
      }
    };

    const checkTextColor = () => {
      const heroSection = document.querySelector('#hero');
      if (!heroSection) return;
      
      const heroBg = getComputedStyle(heroSection).backgroundColor;
      const isDarkBg = heroBg.includes('0, 0, 0') || 
                       heroBg.includes('23, 23, 23') || 
                       heroBg.includes('17, 24, 39');
      
      setLightText(isDarkBg);
    };

    window.addEventListener('scroll', handleScroll);
    checkTextColor(); // Verificar al montar
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
    // Verificar color al cambiar de ruta
    setTimeout(() => {
      const handle = () => {
        if (window.scrollY === 0) {
          const checkTextColor = () => {
            const heroSection = document.querySelector('#hero');
            if (!heroSection) return;
            
            const heroBg = getComputedStyle(heroSection).backgroundColor;
            const isDarkBg = heroBg.includes('0, 0, 0') || 
                             heroBg.includes('23, 23, 23') || 
                             heroBg.includes('17, 24, 39');
            
            setLightText(isDarkBg);
          };
          checkTextColor();
        }
      };
      handle();
    }, 100);
  }, [location]);

  // Clases dinámicas
  const textColorClass = isScrolled 
    ? 'text-gray-900' 
    : lightText 
      ? 'text-white' 
      : 'text-gray-900';

  const hoverClass = isScrolled 
    ? 'hover:bg-gray-100' 
    : lightText 
      ? 'hover:bg-white/10' 
      : 'hover:bg-gray-100';

  const iconColorClass = isScrolled 
    ? 'text-blue-600' 
    : lightText 
      ? 'text-white' 
      : 'text-blue-600';

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-white shadow-md' 
        : 'bg-transparent'
    } ${!isScrolled && lightText ? 'navbar-blur' : ''}`}>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2 hover:scale-105 transition-transform">
              <Stethoscope className={`h-8 w-8 ${iconColorClass}`} />
              <span className={`text-xl font-bold ${textColorClass}`}>PuntoMedico</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-baseline space-x-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-all ${textColorClass} ${hoverClass}`}
                >
                  {link.label}
                </Link>
              ))}
            </div>
            <Link
              to="/carrito"
              className={`p-2 rounded-full transition-all ${hoverClass} hover:scale-105 ${textColorClass}`}
            >
              <ShoppingCart className="h-6 w-6" />
              <span className="sr-only">Carrito</span>
            </Link>
          </div>

          <div className="md:hidden flex items-center">
            <Link
              to="/carrito"
              className={`p-2 rounded-full mr-2 transition-all ${hoverClass} ${textColorClass}`}
            >
              <ShoppingCart className="h-6 w-6" />
              <span className="sr-only">Carrito</span>
            </Link>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`inline-flex items-center justify-center p-2 rounded-md transition-all ${hoverClass} ${textColorClass}`}
              aria-expanded={isOpen}
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              <span className="sr-only">{isOpen ? 'Cerrar menú' : 'Abrir menú'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden transition-all duration-300 ease-in-out overflow-hidden ${
          isOpen
            ? 'max-h-96 opacity-100'
            : 'max-h-0 opacity-0'
        } ${isScrolled ? 'bg-white' : lightText ? 'bg-gray-900' : 'bg-white'}`}
      >
        <div className="px-2 pt-2 pb-3 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`block px-3 py-2 rounded-md text-sm font-medium ${
                isScrolled || !lightText
                  ? 'text-gray-900 hover:bg-gray-100' 
                  : 'text-white hover:bg-white/10'
              }`}
            >
              {link.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};

const navLinks = [
  { path: '/', label: 'Inicio' },
  { path: '/productos', label: 'Productos' },
  { path: '/nosotros', label: 'Nosotros' },
  { path: '/contacto', label: 'Contacto' },
];

export default Navbar;