import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone, Heart, ShoppingCart, Shield } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="animate-slide-up">
            <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
              <Heart className="h-5 w-5 text-blue-500" />
              <span>Punto Medico</span>
            </h3>
            <p className="text-gray-400">
              Distribución de equipo médico profesional en Guadalajara y todo México.
              Calidad y servicio garantizado.
            </p>
          </div>
          
          <div className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <h3 className="text-lg font-semibold mb-4">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-gray-400 hover:text-white transition-colors duration-200 flex items-center space-x-2"
                  >
                    <link.icon className="h-4 w-4" />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <h3 className="text-lg font-semibold mb-4">Contacto</h3>
            <ul className="space-y-4">
              <li className="flex items-center space-x-3 group">
                <MapPin className="h-5 w-5 text-blue-500 group-hover:scale-110 transition-transform duration-200" />
                <span className="text-gray-400 group-hover:text-white transition-colors duration-200">
                Col. El Retiro, Guadalajara
                </span>
              </li>
              <li className="flex items-center space-x-3 group">
                <Phone className="h-5 w-5 text-blue-500 group-hover:scale-110 transition-transform duration-200" />
                <span className="text-gray-400 group-hover:text-white transition-colors duration-200">
                +52 33 3508 0466
                </span>
              </li>
              <li className="flex items-center space-x-3 group">
                <Mail className="h-5 w-5 text-blue-500 group-hover:scale-110 transition-transform duration-200" />
                <span className="text-gray-400 group-hover:text-white transition-colors duration-200">
                  ventas@puntomedico.com
                </span>
              </li>
            </ul>
          </div>
          
          <div className="animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <h3 className="text-lg font-semibold mb-4">Síguenos</h3>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a
                  key={social.name}
                  href={social.url}
                  className="text-gray-400 hover:text-white transition-colors duration-200 hover:scale-110 transform"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <social.icon className="h-6 w-6" />
                </a>
              ))}
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p className="animate-fade-in">
            &copy; {new Date().getFullYear()} PuntoMedico. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

const quickLinks = [
  { path: '/productos', label: 'Productos', icon: ShoppingCart },
  { path: '/nosotros', label: 'Nosotros', icon: Heart },
  { path: '/contacto', label: 'Contacto', icon: Mail },
  { path: '/politicas', label: 'Políticas de Privacidad', icon: Shield },
];

const socialLinks = [
  { name: 'Facebook', icon: Facebook, url: '#' },
  { name: 'Instagram', icon: Instagram, url: '#' },
  { name: 'LinkedIn', icon: Linkedin, url: '#' },
];

export default Footer;