import axios from 'axios';

// Constantes para la API de DHL
const DHL_API_URL = 'https://express.api.dhl.com/mydhl/rates';
const DHL_ACCOUNT_NUMBER = process.env.VITE_DHL_ACCOUNT_NUMBER;
const DHL_API_KEY = process.env.VITE_DHL_API_KEY;

interface ShippingRate {
  service: string;
  totalAmount: number;
  currency: string;
  deliveryTime: string;
  trackingAvailable: boolean;
}

interface ShippingAddress {
  postalCode: string;
  cityName: string;
  countryCode: string;
}

interface Package {
  weight: number; // en kg
  length: number; // en cm
  width: number;  // en cm
  height: number; // en cm
}

// Validación de código postal mexicano
const isValidMexicanPostalCode = (postalCode: string): boolean => {
  return /^[0-9]{5}$/.test(postalCode);
};

export const calculateShipping = async (
  origin: ShippingAddress,
  destination: ShippingAddress,
  packages: Package[]
): Promise<ShippingRate[]> => {
  // Validar códigos postales
  if (!isValidMexicanPostalCode(origin.postalCode) || 
      !isValidMexicanPostalCode(destination.postalCode)) {
    throw new Error('Código postal inválido');
  }

  try {
    // En producción, aquí iría la llamada real a la API de DHL
    // Por ahora, simulamos una respuesta realista basada en la distancia y el peso
    const baseRate = 500; // Tarifa base
    const weightMultiplier = packages.reduce((total, pkg) => total + pkg.weight, 0) * 50;
    const volumeMultiplier = packages.reduce((total, pkg) => 
      total + (pkg.length * pkg.width * pkg.height) / 5000, 0);

    // Simular diferentes zonas basadas en los primeros dos dígitos del CP
    const originZone = parseInt(origin.postalCode.substring(0, 2));
    const destZone = parseInt(destination.postalCode.substring(0, 2));
    const zoneDistance = Math.abs(originZone - destZone);
    const distanceMultiplier = zoneDistance * 10;

    const totalCost = baseRate + weightMultiplier + volumeMultiplier + distanceMultiplier;

    // Simular tiempos de entrega basados en la distancia
    const deliveryDays = Math.min(Math.ceil(zoneDistance / 10), 3);

    return [
      {
        service: 'EXPRESS',
        totalAmount: Math.round(totalCost),
        currency: 'MXN',
        deliveryTime: `${deliveryDays}-${deliveryDays + 1} días hábiles`,
        trackingAvailable: true
      },
      {
        service: 'PRIORITY',
        totalAmount: Math.round(totalCost * 1.5),
        currency: 'MXN',
        deliveryTime: `${Math.max(1, deliveryDays - 1)} día${deliveryDays > 2 ? 's' : ''} hábil${deliveryDays > 2 ? 'es' : ''}`,
        trackingAvailable: true
      }
    ];
  } catch (error) {
    console.error('Error calculating shipping rates:', error);
    throw new Error('Error al calcular costos de envío');
  }
};