import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Truck, CreditCard, Phone, ShoppingCart } from 'lucide-react';

const Home = () => {
  return (
    <div className="flex flex-col min-h-screen page-transition">
      {/* Hero Section */}
      <div 
        className="relative bg-cover bg-center h-[60vh] sm:h-[500px] animate-fade-in"
        style={{
          backgroundImage: "url('./img/Hero.png')"
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/50" />
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8 flex flex-col justify-center h-full">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl animate-slide-up">
            Equipo Médico<br />Profesional
          </h1>
          <p className="mt-6 text-xl text-white max-w-3xl animate-slide-up" style={{ animationDelay: '0.2s' }}>
            Distribución de equipo médico de alta calidad en Guadalajara y todo México.
            Productos certificados y garantizados.
          </p>
          <div className="mt-10 animate-slide-up" style={{ animationDelay: '0.4s' }}>
            <Link
              to="/productos"
              className="inline-flex items-center gap-2 bg-blue-600 px-8 py-3 text-white font-medium rounded-md hover:bg-blue-700 button-hover shadow-lg"
            >
              <ShoppingCart className="h-5 w-5" />
              Ver Catálogo
            </Link>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <div 
                key={feature.title}
                className="text-center p-6 rounded-xl hover:bg-blue-50 transition-all duration-300 animate-slide-up card-hover"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <feature.icon className="w-12 h-12 text-blue-600 mx-auto" />
                <h3 className="mt-4 text-lg font-medium">{feature.title}</h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Featured Products */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-extrabold text-gray-900 text-center mb-12 animate-slide-up">
            Productos Destacados
          </h2>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {featuredProducts.map((product, index) => (
              <div 
                key={product.id} 
                className="bg-white rounded-lg shadow-lg overflow-hidden card-hover animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative">
                  <img src={product.image} alt={product.name} className="w-full h-48 object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
                  <p className="mt-2 text-gray-600">{product.description}</p>
                  <div className="mt-4 flex justify-between items-center">
                    <span className="text-xl font-bold text-blue-600">${product.price}</span>
                    <Link
                      to={`/productos/${product.id}`}
                      className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 button-hover shadow-md"
                    >
                      <ShoppingCart className="h-4 w-4" />
                      Ver Detalles
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const features = [
  {
    icon: Shield,
    title: "Productos Certificados",
    description: "Garantía de calidad en todos nuestros productos"
  },
  {
    icon: Truck,
    title: "Envío FedEx",
    description: "Entrega segura y rápida a todo México"
  },
  {
    icon: CreditCard,
    title: "Pago Seguro",
    description: "Múltiples métodos de pago disponibles"
  },
  {
    icon: Phone,
    title: "Soporte Técnico",
    description: "Asesoría especializada"
  }
];

const featuredProducts = [
  {
    id: 1,
    name: "Monitor de Signos Vitales",
    description: "Monitor multiparamétrico de alta precisión para uso hospitalario",
    price: "45,999",
    image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80"
  },
  {
    id: 2,
    name: "Desfibrilador Automático",
    description: "Desfibrilador externo automático con tecnología bifásica",
    price: "89,999",
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80"
  },
  {
    id: 3,
    name: "Ultrasonido Portátil",
    description: "Sistema de ultrasonido portátil con pantalla táctil",
    price: "159,999",
    image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80"
  }
];

export default Home;