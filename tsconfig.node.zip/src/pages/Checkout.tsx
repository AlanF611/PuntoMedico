import React, { useState } from 'react';
import { CreditCard, Truck, Shield, AlertCircle } from 'lucide-react';

const Checkout = () => {
  const [step, setStep] = useState(1);
  const [shippingMethod, setShippingMethod] = useState('dhl-express');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [formData, setFormData] = useState({
    shipping: {
      firstName: '',
      lastName: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      phone: '',
      email: '',
      instructions: ''
    },
    payment: {
      cardNumber: '',
      expiry: '',
      cvv: '',
      cardName: ''
    }
  });

  const handleInputChange = (section: 'shipping' | 'payment', field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const shippingMethods = [
    {
      id: 'dhl-express',
      name: 'DHL Express',
      description: 'Entrega en 1-2 días hábiles',
      price: 999,
      icon: 'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&q=80'
    },
    {
      id: 'dhl-priority',
      name: 'DHL Priority',
      description: 'Entrega al siguiente día hábil',
      price: 1499,
      icon: 'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&q=80'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-3xl mx-auto">
        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className={`flex items-center ${step >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className="flex items-center justify-center w-8 h-8 border-2 rounded-full">
                1
              </div>
              <span className="ml-2">Envío</span>
            </div>
            <div className={`h-0.5 flex-1 mx-4 ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`} />
            <div className={`flex items-center ${step >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className="flex items-center justify-center w-8 h-8 border-2 rounded-full">
                2
              </div>
              <span className="ml-2">Pago</span>
            </div>
          </div>
        </div>

        {step === 1 ? (
          /* Shipping Information */
          <div className="bg-white p-6 rounded-lg shadow animate-fade-in">
            <h2 className="text-xl font-medium mb-6 flex items-center gap-2">
              <Truck className="h-5 w-5" />
              Información de Envío
            </h2>

            {/* Shipping Methods */}
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-4">Método de Envío</h3>
              <div className="grid gap-4">
                {shippingMethods.map((method) => (
                  <label
                    key={method.id}
                    className={`relative flex items-center p-4 border rounded-lg cursor-pointer transition-all duration-200 ${
                      shippingMethod === method.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="shipping-method"
                      value={method.id}
                      checked={shippingMethod === method.id}
                      onChange={(e) => setShippingMethod(e.target.value)}
                      className="sr-only"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <img
                            src={method.icon}
                            alt={method.name}
                            className="w-12 h-12 object-contain"
                          />
                          <div>
                            <p className="font-medium">{method.name}</p>
                            <p className="text-sm text-gray-500">{method.description}</p>
                          </div>
                        </div>
                        <span className="font-medium">${method.price}</span>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nombre</label>
                  <input
                    type="text"
                    value={formData.shipping.firstName}
                    onChange={(e) => handleInputChange('shipping', 'firstName', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Apellidos</label>
                  <input
                    type="text"
                    value={formData.shipping.lastName}
                    onChange={(e) => handleInputChange('shipping', 'lastName', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Dirección</label>
                <input
                  type="text"
                  value={formData.shipping.address}
                  onChange={(e) => handleInputChange('shipping', 'address', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Ciudad</label>
                  <input
                    type="text"
                    value={formData.shipping.city}
                    onChange={(e) => handleInputChange('shipping', 'city', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Estado</label>
                  <input
                    type="text"
                    value={formData.shipping.state}
                    onChange={(e) => handleInputChange('shipping', 'state', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Código Postal</label>
                  <input
                    type="text"
                    value={formData.shipping.zipCode}
                    onChange={(e) => handleInputChange('shipping', 'zipCode', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Teléfono</label>
                  <input
                    type="tel"
                    value={formData.shipping.phone}
                    onChange={(e) => handleInputChange('shipping', 'phone', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    value={formData.shipping.email}
                    onChange={(e) => handleInputChange('shipping', 'email', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Instrucciones de entrega (opcional)
                </label>
                <textarea
                  value={formData.shipping.instructions}
                  onChange={(e) => handleInputChange('shipping', 'instructions', e.target.value)}
                  rows={3}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <button
                type="button"
                onClick={() => setStep(2)}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors duration-300 flex items-center justify-center gap-2"
              >
                <CreditCard className="h-5 w-5" />
                Continuar al Pago
              </button>
            </form>
          </div>
        ) : (
          /* Payment Information */
          <div className="bg-white p-6 rounded-lg shadow animate-fade-in">
            <h2 className="text-xl font-medium mb-6 flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Información de Pago
            </h2>

            {/* Payment Methods */}
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-4">Método de Pago</h3>
              <div className="grid gap-4">
                <label
                  className={`relative flex items-center p-4 border rounded-lg cursor-pointer transition-all duration-200 ${
                    paymentMethod === 'card'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-200'
                  }`}
                >
                  <input
                    type="radio"
                    name="payment-method"
                    value="card"
                    checked={paymentMethod === 'card'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                    className="sr-only"
                  />
                  <div className="flex items-center gap-3">
                    <Shield className="h-6 w-6 text-blue-600" />
                    <div>
                      <p className="font-medium">Tarjeta de Crédito/Débito</p>
                      <p className="text-sm text-gray-500">Pago seguro con cifrado SSL</p>
                    </div>
                  </div>
                </label>
              </div>
            </div>

            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Número de Tarjeta</label>
                <div className="mt-1 relative">
                  <input
                    type="text"
                    value={formData.payment.cardNumber}
                    onChange={(e) => handleInputChange('payment', 'cardNumber', e.target.value)}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 pl-10"
                    placeholder="1234 5678 9012 3456"
                    required
                  />
                  <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Fecha de Expiración
                  </label>
                  <input
                    type="text"
                    value={formData.payment.expiry}
                    onChange={(e) => handleInputChange('payment', 'expiry', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="MM/YY"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">CVV</label>
                  <div className="mt-1 relative">
                    <input
                      type="text"
                      value={formData.payment.cvv}
                      onChange={(e) => handleInputChange('payment', 'cvv', e.target.value)}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      placeholder="123"
                      required
                    />
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 group">
                      <AlertCircle className="h-5 w-5 text-gray-400" />
                      <div className="hidden group-hover:block absolute right-0 bottom-full mb-2 w-48 p-2 bg-gray-800 text-white text-xs rounded">
                        El código CVV son los 3 dígitos en el reverso de tu tarjeta
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Nombre en la Tarjeta
                </label>
                <input
                  type="text"
                  value={formData.payment.cardName}
                  onChange={(e) => handleInputChange('payment', 'cardName', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>

              {/* Security Notice */}
              <div className="bg-gray-50 p-4 rounded-lg flex items-start gap-3">
                <Shield className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-600">
                  Tus datos están protegidos con cifrado SSL de 256 bits. Nunca compartimos la
                  información de tu tarjeta.
                </p>
              </div>

              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="w-1/2 bg-gray-200 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors duration-300"
                >
                  Volver
                </button>
                <button
                  type="submit"
                  className="w-1/2 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors duration-300 flex items-center justify-center gap-2"
                >
                  <Shield className="h-5 w-5" />
                  Completar Compra
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Order Summary */}
        <div className="mt-8 bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-medium mb-4">Resumen del Pedido</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium">$45,999</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Envío DHL {shippingMethod === 'dhl-express' ? 'Express' : 'Priority'}</span>
              <span className="font-medium">${shippingMethod === 'dhl-express' ? '999' : '1,499'}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">IVA (16%)</span>
              <span className="font-medium">$7,359.84</span>
            </div>
            <div className="pt-3 border-t">
              <div className="flex justify-between">
                <span className="font-medium">Total</span>
                <span className="text-xl font-bold text-blue-600">
                  ${(54357.84 + (shippingMethod === 'dhl-express' ? 999 : 1499)).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;