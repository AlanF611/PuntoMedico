import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen pt-16 page-transition">
      {/* Contact Info */}
      <div className="bg-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold mb-8 animate-slide-up">Contáctanos</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {contactInfo.map((info, index) => (
              <div 
                key={info.title}
                className="flex items-center space-x-4 animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <info.icon className="h-8 w-8" />
                <div>
                  <h3 className="font-medium">{info.title}</h3>
                  <p className="text-blue-100">{info.value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Form and Location */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="animate-slide-up">
            <h2 className="text-2xl font-bold mb-4">Envíanos un Mensaje</h2>
            <p className="text-gray-600 mb-8">
              Estamos aquí para responder cualquier pregunta que tengas sobre nuestros
              productos y servicios.
            </p>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Correo Electrónico
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Teléfono
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mensaje
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              <button
                type="submit"
                className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 flex items-center space-x-2"
              >
                <Send className="h-5 w-5" />
                <span>Enviar Mensaje</span>
              </button>
            </form>
          </div>

          {/* Location Section */}
          <div className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
            {/* Location Card */}
            <div className="contact-card p-6 md:p-8 rounded-2xl shadow-lg bg-white">
              <div className="flex flex-col items-center">
                <div className="contact-icon w-12 h-12 md:w-16 md:h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6 md:w-8 md:h-8 text-blue-600" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-gray-800 mb-2">Ubicaciones</h3>
                <div className="text-gray-600 text-center text-sm md:text-base">
                  <p className="mb-2 font-medium">Sucursal Principal:</p>
                  <p className="mb-4">Col. El Retiro, Guadalajara</p>
                  <p className="mb-2 font-medium">Nueva Sucursal:</p>
                  <p>C. Puerto San Juan 1A, Miramar, 45060 Zapopan</p>
                </div>
              </div>
            </div>

            {/* Maps Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mt-12">
              {/* Main Branch Map */}
              <div className="bg-white p-4 md:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-lg md:text-xl font-semibold text-gray-800 mb-4 text-center">Sucursal Principal</h3>
                <div className="aspect-video rounded-xl overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3732.5368821204397!2d-103.34536962416507!3d20.688412199380238!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8428b1df178618c5%3A0x53896671bb0e17b7!2sPunto%20M%C3%A9dico%20(material%20hospitalario%20y%20renta%20de%20equipo%20m%C3%A9dico)!5e0!3m2!1ses-419!2smx!4v1730935212060!5m2!1ses-419!2smx"
                    className="w-full h-full border-0"
                    allowFullScreen
                    loading="lazy"
                  />
                </div>
              </div>

              {/* New Branch Map */}
              <div className="bg-white p-4 md:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-lg md:text-xl font-semibold text-gray-800 mb-4 text-center">Sucursal Miramar</h3>
                <div className="aspect-video rounded-xl overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3732.041339977246!2d-103.4052493!3d20.7057583!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8428ae4c98571d59%3A0x4b01b51df9f5996e!2sC.%20Puerto%20San%20Juan%201A%2C%20Miramar%2C%2045060%20Zapopan%2C%20Jal.!5e0!3m2!1sen!2smx!4v1710935212060!5m2!1sen!2smx"
                    className="w-full h-full border-0"
                    allowFullScreen
                    loading="lazy"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const contactInfo = [
  {
    icon: MapPin,
    title: 'Dirección',
    value: 'Col. El Retiro, Guadalajara'
  },
  {
    icon: Phone,
    title: 'Teléfono',
    value: '+52 33 3508 0466'
  },
  {
    icon: Mail,
    title: 'Email',
    value: 'ventas@puntomedico.com'
  }
];

export default Contact;