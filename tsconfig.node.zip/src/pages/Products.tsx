import React, { useState } from 'react';
import { Search, Filter, ShoppingCart, Heart } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCart } from '../context/CartContext';

const Products = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState([0, 500000]);
  const { addItem } = useCart();

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesPrice = product.numericPrice >= priceRange[0] && product.numericPrice <= priceRange[1];
    return matchesSearch && matchesCategory && matchesPrice;
  });

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900">Catálogo de Productos</h1>
        <p className="mt-2 text-gray-600">Encuentra el equipo médico que necesitas</p>
      </motion.div>

      {/* Filters and Search */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex flex-col md:flex-row gap-4 mb-8"
      >
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Buscar productos..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="flex gap-4">
          <select
            className="px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="all">Todas las categorías</option>
            <option value="diagnostic">Diagnóstico</option>
            <option value="monitoring">Monitoreo</option>
            <option value="surgery">Cirugía</option>
            <option value="emergency">Emergencia</option>
            <option value="rehabilitation">Rehabilitación</option>
            <option value="laboratory">Laboratorio</option>
          </select>
          <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200">
            <Filter className="h-5 w-5" />
            Filtros
          </button>
        </div>
      </motion.div>

      {/* Product Grid */}
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
      >
        {filteredProducts.map((product) => (
          <motion.div
            key={product.id}
            variants={item}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 group"
          >
            <div className="relative">
              <motion.img
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover"
              />
              <button className="absolute top-2 right-2 p-2 bg-white/80 rounded-full hover:bg-white transition-colors duration-300">
                <Heart className="h-5 w-5 text-gray-600 hover:text-red-500 transition-colors duration-300" />
              </button>
              {product.stock <= 5 && (
                <motion.span
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 text-xs rounded-full"
                >
                  ¡Últimas {product.stock} unidades!
                </motion.span>
              )}
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
                  <p className="mt-1 text-sm text-gray-500">{product.category}</p>
                </div>
                {product.discount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded"
                  >
                    -{product.discount}%
                  </motion.span>
                )}
              </div>
              <p className="mt-2 text-gray-600 text-sm line-clamp-2">{product.description}</p>
              <div className="mt-4">
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-bold text-blue-600">${product.price}</span>
                  {product.discount > 0 && (
                    <span className="text-sm text-gray-400 line-through">${product.originalPrice}</span>
                  )}
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  Envío DHL: ${product.shipping}
                </div>
              </div>
              <div className="mt-4 flex justify-between items-center">
                <span className="text-sm text-gray-500">
                  {product.stock > 0 ? `${product.stock} disponibles` : 'Agotado'}
                </span>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => product.stock > 0 && addItem({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    image: product.image
                  })}
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors duration-300 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={product.stock === 0}
                >
                  <ShoppingCart className="h-4 w-4" />
                  {product.stock === 0 ? 'Agotado' : 'Agregar'}
                </motion.button>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
};

const products = [
  {
    id: 1,
    name: "Monitor de Signos Vitales",
    category: "Monitoreo",
    description: "Monitor multiparamétrico de alta precisión para uso hospitalario. Incluye ECG, SpO2, NIBP, y temperatura.",
    price: "45,999",
    numericPrice: 45999,
    originalPrice: "52,999",
    discount: 13,
    shipping: "999",
    stock: 8,
    image: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80"
  },
  {
    id: 2,
    name: "Desfibrilador Automático",
    category: "Emergencia",
    description: "Desfibrilador externo automático con tecnología bifásica y pantalla LCD de alta resolución.",
    price: "89,999",
    numericPrice: 89999,
    shipping: "1,499",
    stock: 5,
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80"
  },
  {
    id: 3,
    name: "Ultrasonido Portátil",
    category: "Diagnóstico",
    description: "Sistema de ultrasonido portátil con pantalla táctil y sondas intercambiables.",
    price: "159,999",
    numericPrice: 159999,
    originalPrice: "179,999",
    discount: 11,
    shipping: "1,999",
    stock: 3,
    image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&q=80"
  },
  {
    id: 4,
    name: "Mesa Quirúrgica Eléctrica",
    category: "Cirugía",
    description: "Mesa quirúrgica con control eléctrico y posiciones programables. Capacidad de carga hasta 250kg.",
    price: "249,999",
    numericPrice: 249999,
    shipping: "4,999",
    stock: 2,
    image: "https://images.unsplash.com/photo-1579684453423-f84349ef60b0?auto=format&fit=crop&q=80"
  },
  {
    id: 5,
    name: "Equipo de Anestesia",
    category: "Cirugía",
    description: "Sistema completo de anestesia con ventilador integrado y monitoreo de gases.",
    price: "299,999",
    numericPrice: 299999,
    shipping: "5,999",
    stock: 1,
    image: "https://images.unsplash.com/photo-1583912267550-d6c2ac4b0154?auto=format&fit=crop&q=80"
  },
  {
    id: 6,
    name: "Caminadora Rehabilitación",
    category: "Rehabilitation",
    description: "Caminadora especializada para rehabilitación con barras paralelas y panel de control.",
    price: "89,999",
    numericPrice: 89999,
    originalPrice: "99,999",
    discount: 10,
    shipping: "3,999",
    stock: 4,
    image: "https://images.unsplash.com/photo-1576678927484-cc907957088c?auto=format&fit=crop&q=80"
  },
  {
    id: 7,
    name: "Microscopio Digital",
    category: "Laboratory",
    description: "Microscopio de laboratorio con cámara digital integrada y software de análisis.",
    price: "129,999",
    numericPrice: 129999,
    shipping: "1,499",
    stock: 6,
    image: "https://images.unsplash.com/photo-1516728043722-b394cb2f689e?auto=format&fit=crop&q=80"
  },
  {
    id: 8,
    name: "Lámpara Quirúrgica LED",
    category: "Cirugía",
    description: "Lámpara LED de doble brazo con control de intensidad y temperatura de color.",
    price: "79,999",
    numericPrice: 79999,
    shipping: "2,999",
    stock: 0,
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80"
  }
];

export default Products;