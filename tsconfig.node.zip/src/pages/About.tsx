import React from 'react';
import { Users, Award, Clock, Building } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen pt-16 page-transition">
      {/* Hero Section con imagen */}
      <div className="relative bg-blue-600 text-white py-16 h-96 overflow-hidden">
        {/* Imagen de fondo */}
        <div className="absolute inset-0 z-0">
          <img 
            src="./img/About.png" // Asegúrate de tener esta imagen en tu carpeta public
            alt="Equipo médico"
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-slide-up">¿Quiénes Somos?</h1>
          <p className="text-xl max-w-3xl animate-slide-up" style={{ animationDelay: '0.2s' }}>
            Servicio y Soluciones para el sector salud en Guadalajara y todo México.
          </p>
        </div>
      </div>

      {/* Sección de introducción */}
      <div className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-gray-900">Bienvenidos a Punto Médico</h2>
            <p className="text-lg text-gray-600 mb-6">
              Su proveedor de confianza de material hospitalario en Guadalajara, Jalisco. Ubicados en la Colonia El Retiro, 
              nos dedicamos a ofrecer soluciones de calidad para el sector de la salud, priorizando siempre la seguridad y el bienestar.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              En Punto Médico, entendemos la importancia de contar con insumos médicos confiables y eficientes. Por eso, 
              trabajamos con los mejores fabricantes y distribuidores, asegurando que nuestros productos cumplan con los más 
              altos estándares de calidad.
            </p>
            <p className="text-lg text-gray-600">
              Nuestro equipo está compuesto por profesionales comprometidos y capacitados, dispuestos a brindar un servicio 
              personalizado y asesoría experta. Ya sea que necesite equipos médicos, insumos quirúrgicos o materiales de higiene, 
              estamos aquí para ayudarle a encontrar lo que necesita.
            </p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div 
                key={stat.label}
                className="text-center p-6 rounded-xl hover:bg-blue-50 transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <stat.icon className="w-8 h-8 text-blue-600 mx-auto mb-4" />
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Mission & Vision */}
      <div className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-50 p-8 rounded-lg shadow-md animate-slide-up">
              <h2 className="text-2xl font-bold mb-4 text-gray-900">Nuestra Misión</h2>
              <p className="text-gray-600">
                Proporcionar equipo médico de la más alta calidad a profesionales de la salud,
                contribuyendo al mejoramiento de la atención médica en México a través de
                tecnología innovadora y servicio excepcional.
              </p>
            </div>
            <div className="bg-gray-50 p-8 rounded-lg shadow-md animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <h2 className="text-2xl font-bold mb-4 text-gray-900">Nuestra Visión</h2>
              <p className="text-gray-600">
                Ser la empresa líder en distribución de equipo médico en México, reconocida
                por nuestra excelencia en servicio, calidad de productos y compromiso con
                el sector salud.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const stats = [
  { icon: Users, value: '1000+', label: 'Clientes Satisfechos' },
  { icon: Award, value: '15+', label: 'Años de Experiencia' },
  { icon: Clock, value: '24/7', label: 'Soporte Técnico' },
  { icon: Building, value: '50+', label: 'Hospitales Atendidos' },
];

export default About;